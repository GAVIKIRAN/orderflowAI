// ── Utilities ────────────────────────────────────────────────────
function esc(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function now() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// ── View switching ────────────────────────────────────────────────
function showView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.getElementById('view-' + name).classList.add('active');
  document.querySelector(`[data-view="${name}"]`).classList.add('active');
  if (name === 'dashboard') loadDashboard();
}

// ── Quick command injection ───────────────────────────────────────
function injectCmd(text) {
  const input = document.getElementById('chatInput');
  input.value = text;
  autoResize(input);
  showView('chat');
  input.focus();
}

// ── Chat helpers ──────────────────────────────────────────────────
const $msgs = () => document.getElementById('chatMessages');

function scrollBottom() {
  const el = $msgs();
  requestAnimationFrame(() => { el.scrollTop = el.scrollHeight; });
}

function appendMsg(role, bubbleHTML, bubbleClass = '') {
  const row = document.createElement('div');
  row.className = `msg-row ${role}`;

  const avatarIcon = role === 'user' ? 'ti-user' : 'ti-robot';
  const avatarClass = role === 'user' ? 'user-avatar' : 'ai-avatar';
  const senderName = role === 'user' ? 'You' : 'OrderFlow AI';

  row.innerHTML = `
    <div class="msg-avatar ${avatarClass}" aria-hidden="true">
      <i class="ti ${avatarIcon}"></i>
    </div>
    <div class="msg-content">
      <div class="msg-meta">${senderName} <span class="msg-time">${now()}</span></div>
      <div class="msg-bubble ${bubbleClass}">${bubbleHTML}</div>
    </div>
  `;
  $msgs().appendChild(row);
  scrollBottom();
  return row;
}

function showTyping() {
  const row = document.createElement('div');
  row.className = 'msg-row ai';
  row.id = 'typingRow';
  row.innerHTML = `
    <div class="msg-avatar ai-avatar" aria-hidden="true"><i class="ti ti-robot"></i></div>
    <div class="msg-content">
      <div class="msg-meta">OrderFlow AI</div>
      <div class="msg-bubble">
        <div class="typing-indicator" aria-label="AI is thinking">
          <span></span><span></span><span></span>
        </div>
      </div>
    </div>
  `;
  $msgs().appendChild(row);
  scrollBottom();
}

function removeTyping() {
  const el = document.getElementById('typingRow');
  if (el) el.remove();
}

// ── Status badge ──────────────────────────────────────────────────
function statusBadge(status) {
  const map = {
    'Received':  'badge-received',
    'In Review': 'badge-review',
    'Accepted':  'badge-accepted',
  };
  const cls = map[status] || 'badge-received';
  return `<span class="badge ${cls}"><span class="badge-dot"></span>${esc(status)}</span>`;
}

// ── Order card ────────────────────────────────────────────────────
function renderOrderCard(order) {
  const fields = [
    { k: 'Part',      v: order.part_name  || '—' },
    { k: 'Material',  v: order.material   || '—' },
    { k: 'Quantity',  v: order.quantity ? `${order.quantity} units` : '—' },
    { k: 'Specs',     v: order.specs      || '—' },
    { k: 'Deadline',  v: order.deadline   || '—' },
    { k: 'Status',    v: statusBadge(order.status) },
  ];
  return `
    <div class="order-card">
      <div class="order-card-header">
        <span><i class="ti ti-package" style="margin-right:6px"></i>ORDER #${order.id}</span>
        <span>${statusBadge(order.status)}</span>
      </div>
      <div class="order-card-grid">
        ${fields.map(f => `
          <div class="order-field">
            <div class="field-key">${f.k}</div>
            <div class="field-val">${f.v}</div>
          </div>
        `).join('')}
      </div>
    </div>`;
}

// ── Quality log card ──────────────────────────────────────────────
function renderQualityCard(order) {
  if (!order.quality_logs || !order.quality_logs.length) return '';
  return `
    <div class="quality-card">
      <div class="quality-header">
        <i class="ti ti-shield-check"></i>
        QUALITY LOG — Order #${order.id}
      </div>
      ${order.quality_logs.map(log => `
        <div class="quality-entry">
          <div class="q-time">${esc(log.time)}</div>
          <div class="q-note">${esc(log.note)}</div>
        </div>
      `).join('')}
    </div>`;
}

// ── Handle API response ───────────────────────────────────────────
function handleResponse(data) {
  const { type } = data;

  if (type === 'order_created') {
    appendMsg('ai', `<p>${esc(data.message)}</p>${renderOrderCard(data.order)}`, 'success');
  } else if (type === 'status_updated') {
    appendMsg('ai', `<p>${esc(data.message)}</p>${renderOrderCard(data.order)}${renderQualityCard(data.order)}`, 'success');
  } else if (type === 'quality_logged') {
    appendMsg('ai', `<p>${esc(data.message)}</p>${renderQualityCard(data.order)}`, 'success');
  } else if (type === 'order_info') {
    appendMsg('ai', `<p>${esc(data.message)}</p>${renderOrderCard(data.order)}${renderQualityCard(data.order)}`);
  } else if (type === 'order_list') {
    const cards = (data.orders || []).map(renderOrderCard).join('');
    appendMsg('ai', `<p>${esc(data.message)}</p>${cards || '<p>No orders found.</p>'}`);
  } else if (type === 'error') {
    appendMsg('ai', `<p>${esc(data.message)}</p>`, 'error');
  } else {
    appendMsg('ai', `<p>${esc(data.message || 'Unexpected response.')}</p>`);
  }
}

// ── Send message ──────────────────────────────────────────────────
async function sendMessage() {
  const input = document.getElementById('chatInput');
  const btn   = document.getElementById('sendBtn');
  const text  = input.value.trim();
  if (!text) return;

  appendMsg('user', `<p>${esc(text)}</p>`);
  input.value = '';
  autoResize(input);
  btn.disabled = true;
  showTyping();

  try {
    const res  = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text }),
    });
    const data = await res.json();
    removeTyping();
    handleResponse(data);
  } catch {
    removeTyping();
    appendMsg('ai', `<p>Could not reach the server. Is Flask running on port 5000?</p>`, 'error');
  } finally {
    btn.disabled = false;
    input.focus();
  }
}

// ── Keyboard & resize ─────────────────────────────────────────────
function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

// ── Dashboard ─────────────────────────────────────────────────────
let allOrders = [];
let activeFilter = 'all';

async function loadDashboard() {
  try {
    const res = await fetch('/api/orders');
    allOrders = await res.json();
    renderDashboard(allOrders);
  } catch {
    document.getElementById('ordersTableBody').innerHTML =
      '<tr><td colspan="7" class="table-empty"><i class="ti ti-alert-circle"></i> Failed to load orders.</td></tr>';
  }
}

function filterTable(status, btn) {
  activeFilter = status;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderDashboard(allOrders);
}

function renderDashboard(orders) {
  const total    = orders.length;
  const received = orders.filter(o => o.status === 'Received').length;
  const review   = orders.filter(o => o.status === 'In Review').length;
  const accepted = orders.filter(o => o.status === 'Accepted').length;

  document.getElementById('statTotal').textContent    = total;
  document.getElementById('statReceived').textContent = received;
  document.getElementById('statReview').textContent   = review;
  document.getElementById('statAccepted').textContent = accepted;

  const filtered = activeFilter === 'all'
    ? orders
    : orders.filter(o => o.status === activeFilter);

  const tbody = document.getElementById('ordersTableBody');

  if (!filtered.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="table-empty"><i class="ti ti-inbox"></i> No orders found.</td></tr>';
    return;
  }

  const sorted = [...filtered].sort((a, b) => b.id - a.id);

  tbody.innerHTML = sorted.map(o => {
    const latestQ = o.quality_logs && o.quality_logs.length
      ? o.quality_logs[o.quality_logs.length - 1].note
      : '—';
    return `
      <tr>
        <td class="order-id-cell">#${o.id}</td>
        <td class="part-name-cell">${esc(o.part_name)}</td>
        <td>${esc(o.material || '—')}</td>
        <td>${o.quantity}</td>
        <td>${esc(o.deadline || '—')}</td>
        <td>${statusBadge(o.status)}</td>
        <td class="quality-cell">${esc(latestQ)}</td>
      </tr>`;
  }).join('');
}
